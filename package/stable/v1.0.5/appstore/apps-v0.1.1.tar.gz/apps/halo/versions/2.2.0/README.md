------------------------------

## 快速开始 ##

```
docker run \
  -it -d \
  --name halo \
  -p 8090:8090 \
  -v ~/.halo2:/root/.halo2 \
  halohub/halo:2.2 \
  --halo.external-url=http://localhost:8090/ \
  --halo.security.initializer.superadminuser=admin \
  --halo.security.initializer.superadminpassword=P@88w0rd
```

以上仅作为体验使用，详细部署文档请查阅：<https://docs.halo.run/getting-started/install/docker-compose>

## 在线体验 ##

- 环境地址：<https://demo.halo.run>
- 后台地址：<https://demo.halo.run/console>
- 用户名：`demo`
- 密码：`P@ssw0rd123..`

## 生态 ##

可访问 [awesome-halo](https://github.com/halo-sigs/awesome-halo) 查看已经适用于 Halo 2.0 的主题和插件，以及适用于 Halo
1.x 的相关仓库。

## 许可证 ##

[![license](https://img.shields.io/github/license/halo-dev/halo.svg?style=flat-square)](https://github.com/halo-dev/halo/blob/master/LICENSE)

Halo 使用 GPL-v3.0 协议开源，请遵守开源协议。

## 贡献 ##

参考 [CONTRIBUTING](https://github.com/halo-dev/halo/blob/master/CONTRIBUTING.md)。

<a href="https://github.com/halo-dev/halo/graphs/contributors"><img src="https://opencollective.com/halo/contributors.svg?width=890&button=false" /></a>

## 状态 ##

![Repobeats analytics](https://repobeats.axiom.co/api/embed/ad008b2151c22e7cf734d2688befaa795d593b95.svg "Repobeats analytics image")
