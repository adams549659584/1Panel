Copyright (c) 2000, 2022, Oracle and/or its affiliates.

This is a release of MySQL, an SQL database server.

License information can be found in the LICENSE file.

In test packages where this file is renamed README-test, the license
file is renamed LICENSE-test.

This distribution may include materials developed by third parties.
For license and attribution notices for these materials,
please refer to the LICENSE file.

For further information on MySQL or additional documentation, visit
http://dev.mysql.com/doc/

For additional downloads and the source of MySQL, visit
http://dev.mysql.com/downloads/

MySQL is brought to you by the MySQL team at Oracle.
