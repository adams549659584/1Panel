phpMyAdmin - Readme
===================

Version 5.3.0-dev

A web interface for MySQL and MariaDB.

https://www.phpmyadmin.net/

Summary
-------

phpMyAdmin is intended to handle the administration of MySQL over the web.
For a summary of features, list of requirements, and installation instructions,
please see the documentation in the ./doc/ folder or at https://docs.phpmyadmin.net/

Copyright
---------

Copyright © 1998 onwards -- the phpMyAdmin team

Certain libraries are copyrighted by their respective authors;
see the full copyright list for details.

For full copyright information, please see ./doc/copyright.rst

License
-------

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License version 2, as published by the
Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

Licensing of current contributions
----------------------------------

Beginning on 2013-12-01, new contributions to this codebase are all licensed
under terms compatible with GPLv2-or-later.  phpMyAdmin is currently
transitioning older code to GPLv2-or-later, but work is not yet complete.

Enjoy!
------

The phpMyAdmin team
